---
name: commit-directly-to-main
description: "In the youtube-clone repo, commit plan steps directly to main without feature branches"
metadata:
  node_type: memory
  type: feedback
  originSessionId: bdc1317d-aafa-48f3-800b-f9c5f78367f1
  modified: 2026-11-07T20:01:18.671Z
---

Commit each plan step directly to `main` in youtube-clone; do not create a branch per step.

**Why:** the user chose this on 2026-11-07 after being asked. It's a solo repo where each plan step is one commit, so branches add merging without adding readability.

**How to apply:** commit on `main` when a commit is requested or a step's workflow calls for one. This does not authorize pushing; push only when asked. Pushing from Claude's session has failed for lack of GitHub credentials, and the user has pushed from their own terminal.
