---
name: frontend-toolchain-pins
description: Why the frontend stays on Vite 7 and TypeScript 5; bumping either breaks the build
metadata:
  node_type: memory
  type: project
  originSessionId: d2f6f7f4-8834-41ea-88fe-90be3a1f486c
  modified: 2026-11-09T18:18:48.456Z
---

Frontend is pinned to Vite 7 and TypeScript 5 on purpose.

- Vite 8 uses Rolldown, whose native binary dies with "Illegal instruction" on the dev machine (i5-2430M, no AVX2/BMI).
- openapi-typescript 7 needs `typescript ^5` and crashes on TS 7 (no JS compiler API).

**Why:** a grader's VM with a basic virtual CPU could hit the same Rolldown crash during `./install.sh`, and API type generation stops working on TS 7.

**How to apply:** don't accept a Vite 8 / TS 7 bump unless the build is re-verified on this CPU and openapi-typescript supports the new TS.
